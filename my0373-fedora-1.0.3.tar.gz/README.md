# Ansible Collection - my0373.laptop

This is a little collection of roles I use to configure my Fedora laptop

Some key things that need to be added

* selinux enforcing
* firewall enforcing
* chrony installed and configured to use ntp servers
* install a few of my favourite tools (tree, vim-enhanced, htop, netcat)
